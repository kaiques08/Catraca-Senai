<?php

require_once __DIR__ . '/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input) || empty($input['cpf']) || empty($input['tipo']) || empty($input['motivo']) || empty($input['hora'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Campos obrigatórios: cpf, tipo, motivo, hora']);
    exit;
}

$cpf    = (string)$input['cpf'];
$tipo   = (string)$input['tipo'];   // entrada, saida, uniforme, etc.
$motivo = (string)$input['motivo'];
$hora   = (string)$input['hora'];   // HH:MM

try {
    $qr = obterCodigoQR($tipo, $motivo, $hora);

    if ($qr === null) {
        // Não é necessário ticket (por exemplo, entrada normal)
        echo json_encode([
            'success' => true,
            'ticket'  => null,
            'message' => 'Não é necessário gerar ticket para este horário/tipo.',
        ]);
        exit;
    }

    $ticket = criarTicket($cpf, $motivo, $tipo, $qr);

    echo json_encode([
        'success' => true,
        'ticket'  => $ticket,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Erro interno ao gerar ticket',
    ]);
}


