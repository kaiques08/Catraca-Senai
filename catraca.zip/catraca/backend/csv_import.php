<?php
declare(strict_types=1);
require __DIR__ . '/secure_bootstrap.php';
require_auth();

$allowed = array_filter(array_map('trim', explode(',', getenv('CSV_ALLOWED_TABLES') ?: '')));

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $token = csrf_token();
    echo '<!doctype html><html><head><meta charset="utf-8"><title>Importar CSV</title></head><body>';
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="hidden" name="csrf_token" value="' . $token . '">';
    echo '<label>Tabela: <input name="table" required></label>';
    echo '<input type="file" name="csv_file" accept=".csv,text/csv" required>';
    echo '<button type="submit">Enviar</button>';
    echo '</form>';
    echo '</body></html>';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

if (!verify_csrf($_POST['csrf_token'] ?? '')) { http_response_code(403); echo 'Token inválido'; exit; }

if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) { http_response_code(400); echo 'Arquivo inválido'; exit; }

$filename = $_FILES['csv_file']['name'] ?? '';
$size = (int)($_FILES['csv_file']['size'] ?? 0);
$tmp = $_FILES['csv_file']['tmp_name'] ?? '';
if ($size <= 0 || $size > 5 * 1024 * 1024) { http_response_code(400); echo 'Tamanho inválido'; exit; }
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
if ($ext !== 'csv') { http_response_code(400); echo 'Extensão inválida'; exit; }

$table = trim((string)($_POST['table'] ?? ''));
if ($table === '' || !preg_match('/^[A-Za-z0-9_]+$/', $table)) { http_response_code(400); echo 'Tabela inválida'; exit; }
if (!empty($allowed) && !in_array($table, $allowed, true)) { http_response_code(403); echo 'Tabela não permitida'; exit; }

ini_set('auto_detect_line_endings', '1');

$f = fopen($tmp, 'rb');
if ($f === false) { http_response_code(400); echo 'Falha ao abrir'; exit; }

$header = fgetcsv($f, 0, ',', '"', '\\');
if ($header === false || count($header) === 0) { fclose($f); http_response_code(400); echo 'Cabeçalho ausente'; exit; }

$cols = array_map(function($c){ return trim((string)$c); }, $header);
foreach ($cols as $c) {
    if ($c === '' || !preg_match('/^[A-Za-z0-9_]+$/', $c)) { fclose($f); http_response_code(400); echo 'Coluna inválida'; exit; }
}

$placeholders = array_map(function($c){ return ':' . $c; }, $cols);
$sql = 'INSERT INTO ' . $table . ' (' . implode(',', $cols) . ') VALUES (' . implode(',', $placeholders) . ')';

$pdo = getPDO();
$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare($sql);
    $count = 0;
    while (($row = fgetcsv($f, 0, ',', '"', '\\')) !== false) {
        if (count($row) !== count($cols)) { throw new RuntimeException('Colunas incompatíveis'); }
        $data = [];
        foreach ($cols as $i => $col) {
            $val = $row[$i];
            if (!mb_detect_encoding($val, 'UTF-8', true)) { $val = mb_convert_encoding($val, 'UTF-8'); }
            $data[':' . $col] = $val;
        }
        $stmt->execute($data);
        $count++;
    }
    fclose($f);
    $pdo->commit();
    echo 'Linhas inseridas: ' . $count;
} catch (Throwable $e) {
    fclose($f);
    $pdo->rollBack();
    http_response_code(400);
    echo 'Erro: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
