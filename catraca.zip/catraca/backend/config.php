<?php
// Configuração básica de conexão com o banco de dados MySQL.
// Ajuste os valores conforme seu ambiente.

define('DB_HOST', 'localhost');
define('DB_NAME', 'controle_catraca');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getPDO(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $host    = getenv('DB_HOST') ?: DB_HOST;
    $db      = getenv('DB_NAME') ?: DB_NAME;
    $user    = getenv('DB_USER') ?: DB_USER;
    $pass    = getenv('DB_PASS') ?: DB_PASS;
    $charset = getenv('DB_CHARSET') ?: DB_CHARSET;
    $persist = filter_var(getenv('DB_PERSISTENT') ?: 'false', FILTER_VALIDATE_BOOLEAN);
    $timeout = (int)(getenv('DB_TIMEOUT') ?: 5);

    $dsn = 'mysql:host=' . $host . ';dbname=' . $db . ';charset=' . $charset;

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_PERSISTENT         => $persist,
        PDO::ATTR_TIMEOUT            => max(1, $timeout),
    ];

    if (defined('PDO::MYSQL_ATTR_INIT_COMMAND')) {
        $options[PDO::MYSQL_ATTR_INIT_COMMAND] = 'SET NAMES ' . $charset . ' COLLATE utf8mb4_unicode_ci';
    }

    $attempts = 0;
    $lastError = null;
    while ($attempts < 3) {
        try {
            $pdo = new PDO($dsn, $user, $pass, $options);
            $pdo->query('SELECT 1');
            return $pdo;
        } catch (Throwable $e) {
            $lastError = $e;
            $attempts++;
            usleep(200000);
        }
    }

    throw new RuntimeException('Falha ao conectar ao banco de dados', 0, $lastError);
}


