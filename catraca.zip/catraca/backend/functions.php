<?php

require_once __DIR__ . '/config.php';

/**
 * Retorna data e hora atuais já formatadas.
 */
function obterDataHora(): array
{
    $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $data = $agora->format('d/m/y');
    $hora = $agora->format('H:i');

    return [
        'data' => $data,
        'hora' => $hora,
        'agora' => $agora,
    ];
}

/**
 * Busca aluno por CPF.
 * Se não encontrar, cria um "aluno genérico" como no frontend atual.
 */
function buscarAluno(string $cpf): array
{
    $pdo = getPDO();

    $stmt = $pdo->prepare('SELECT id, cpf, nome, turma FROM alunos WHERE cpf = :cpf LIMIT 1');
    $stmt->execute(['cpf' => $cpf]);
    $aluno = $stmt->fetch();

    if ($aluno) {
        return $aluno;
    }

    // Se não existir no banco, cria um padrão (comportamento parecido com o JS atual)
    $cpfLimpo = preg_replace('/\D/', '', $cpf);
    $nome = 'Aluno ' . $cpfLimpo;
    $turma = 'XXXX';

    $stmt = $pdo->prepare(
        'INSERT INTO alunos (cpf, nome, turma, created_at) VALUES (:cpf, :nome, :turma, NOW())'
    );
    $stmt->execute([
        'cpf'   => $cpf,
        'nome'  => $nome,
        'turma' => $turma,
    ]);

    $id = (int)$pdo->lastInsertId();

    return [
        'id'    => $id,
        'cpf'   => $cpf,
        'nome'  => $nome,
        'turma' => $turma,
    ];
}

/**
 * Gera código QR e instruções com a mesma lógica do frontend.
 */
function obterCodigoQR(string $tipo, string $motivo, string $horaAtual): ?array
{
    [$h, $m] = array_map('intval', explode(':', $horaAtual));
    $minutosTotais = $h * 60 + $m;

    // Horários de referência em minutos
    $entradaInicio     = 7 * 60;       // 07:00
    $entradaFim        = 7 * 60 + 40;  // 07:40
    $atrasoLeve        = 7 * 60 + 41;  // 07:41
    $atrasoModerado    = 7 * 60 + 50;  // 07:50
    $atrasoGrave       = 7 * 60 + 51;  // 07:51
    $saidaInicio       = 17 * 60 + 20; // 17:20
    $saidaFim          = 17 * 60 + 50; // 17:50

    switch ($tipo) {
        case 'entrada':
            if ($minutosTotais >= $entradaInicio && $minutosTotais <= $entradaFim) {
                // Entrada normal - sem ticket necessário
                return null;
            }
            if ($minutosTotais >= $atrasoLeve && $minutosTotais <= $atrasoModerado) {
                // Atraso leve: 07:41 às 07:50 - QR 100 a 200
                return [
                    'codigo'      => random_int(100, 200),
                    'instrucoes'  => 'Este ticket deve ser apresentado ao professor na sala/oficina/lab. O professor verificará o atraso (5 minutos). Se estiver ok, fará o apontamento no portal, senão encaminhará ao apoio.',
                ];
            }
            if ($minutosTotais >= $atrasoGrave) {
                // Atraso grave: 07:51 em diante - QR 300 a 400
                return [
                    'codigo'      => random_int(300, 400),
                    'instrucoes'  => 'Atraso após 07:51. O aluno deve dirigir-se ao apoio AQVs.',
                ];
            }
            break;

        case 'saida':
            if ($minutosTotais >= $saidaInicio && $minutosTotais <= $saidaFim) {
                // Saída normal - sem ticket necessário
                return null;
            }
            break;

        case 'saida_apoio':
            // Saída autorizada pelo apoio - QR 500 a 600 com responsável
            $codigo = random_int(500, 600);
            $responsavel = '';
            if ($codigo >= 500 && $codigo <= 524) {
                $responsavel = 'Lara';
            } elseif ($codigo >= 525 && $codigo <= 550) {
                $responsavel = 'Lucélia';
            } elseif ($codigo >= 551 && $codigo <= 574) {
                $responsavel = 'Lúcia';
            } else {
                $responsavel = 'Luana';
            }

            return [
                'codigo'     => $codigo,
                'instrucoes' => 'Saída autorizada pelo apoio AQVs. Responsável: ' . $responsavel,
            ];

        case 'saida_esporte':
            return [
                'codigo'     => random_int(700, 800),
                'instrucoes' => 'Saída autorizada por esporte (Anderli). Horário restrito para banho e almoço (ex: 12:00 às 13:00). Não perambular nos ambientes. Se ultrapassar o período, acertar nova autorização com o apoio, justificando-se.',
            ];

        case 'saida_biblioteca':
            return [
                'codigo'     => random_int(900, 949),
                'instrucoes' => 'Saída autorizada pela biblioteca. Deve haver encaminhamento do apoio justificando permanência, pesquisa, trabalho, reposição e atividades extracurriculares.',
            ];

        case 'saida_tutor':
            return [
                'codigo'     => random_int(950, 999),
                'instrucoes' => 'Saída autorizada pelo TUTOR do TCC do grupo. O tutor solicitou antecipadamente ao apoio (AQVs) a autorização com especificação do horário de saída.',
            ];

        case 'cracha_esquecimento':
            return [
                'codigo'     => random_int(200, 249),
                'instrucoes' => 'Esquecimento de crachá. Permitido 2x no mês. No terceiro, entra, mas deve dirigir-se ao apoio.',
            ];

        case 'cracha_perda':
            return [
                'codigo'     => random_int(250, 299),
                'instrucoes' => 'Perda de crachá. Permitido 3x na semana. Em consulta à secretaria; demora um dia para emissão. Na 4x, entra, mas deve dirigir-se ao apoio.',
            ];

        case 'uniforme':
            return [
                'codigo'     => random_int(400, 449),
                'instrucoes' => 'Sem uniforme, avental ou camiseta SENAI. Permitido 1x no mês. No 2x, encaminhado ao apoio. Sugestão: Manter 17 aventais de tamanho médio envelopado na recepção.',
            ];
    }

    return null;
}

/**
 * Verifica limite de ocorrências usando tabela "ocorrencias".
 * - esquecimento: limite 2x por mês
 * - perda: limite 3x por semana
 * - uniforme: limite 1x por mês
 */
function verificarLimite(string $cpf, string $tipo): bool
{
    $pdo = getPDO();
    $hoje = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));

    switch ($tipo) {
        case 'esquecimento':
        case 'uniforme':
            $inicio = (clone $hoje)->modify('first day of this month')->setTime(0, 0, 0);
            $fim    = (clone $hoje)->modify('last day of this month')->setTime(23, 59, 59);
            $limite = $tipo === 'esquecimento' ? 2 : 1;
            break;

        case 'perda':
            // Semana corrente (segunda a domingo)
            $inicio = (clone $hoje)->modify('monday this week')->setTime(0, 0, 0);
            $fim    = (clone $hoje)->modify('sunday this week')->setTime(23, 59, 59);
            $limite = 3;
            break;

        default:
            // Tipos não controlados
            return true;
    }

    $stmt = $pdo->prepare(
        'SELECT COUNT(*) AS total 
         FROM ocorrencias 
         WHERE cpf = :cpf 
           AND tipo = :tipo 
           AND data BETWEEN :inicio AND :fim'
    );

    $stmt->execute([
        'cpf'    => $cpf,
        'tipo'   => $tipo,
        'inicio' => $inicio->format('Y-m-d'),
        'fim'    => $fim->format('Y-m-d'),
    ]);

    $row = $stmt->fetch();
    $total = $row ? (int)$row['total'] : 0;

    return $total < $limite;
}

/**
 * Registra uma ocorrência (esquecimento/perda/uniforme).
 */
function registrarOcorrencia(string $cpf, string $tipo): void
{
    $pdo = getPDO();
    $stmt = $pdo->prepare(
        'INSERT INTO ocorrencias (cpf, tipo, data, created_at) 
         VALUES (:cpf, :tipo, CURDATE(), NOW())'
    );

    $stmt->execute([
        'cpf'  => $cpf,
        'tipo' => $tipo,
    ]);
}

/**
 * Cria um ticket e salva na tabela "tickets".
 */
function criarTicket(string $cpf, string $motivo, string $tipo, array $qr): array
{
    $pdo = getPDO();

    $aluno = buscarAluno($cpf);
    $dataHora = obterDataHora();

    $stmt = $pdo->prepare(
        'INSERT INTO tickets (aluno_id, cpf, motivo, tipo, qr_codigo, qr_instrucoes, data, hora, created_at)
         VALUES (:aluno_id, :cpf, :motivo, :tipo, :qr_codigo, :qr_instrucoes, :data, :hora, NOW())'
    );

    $stmt->execute([
        'aluno_id'      => $aluno['id'] ?? null,
        'cpf'           => $cpf,
        'motivo'        => $motivo,
        'tipo'          => $tipo,
        'qr_codigo'     => $qr['codigo'],
        'qr_instrucoes' => $qr['instrucoes'],
        'data'          => DateTime::createFromFormat('d/m/y', $dataHora['data'])->format('Y-m-d'),
        'hora'          => $dataHora['hora'],
    ]);

    $ticketId = (int)$pdo->lastInsertId();

    return [
        'id'       => $ticketId,
        'aluno'    => $aluno,
        'motivo'   => $motivo,
        'tipo'     => $tipo,
        'qr'       => $qr,
        'data'     => $dataHora['data'],
        'hora'     => $dataHora['hora'],
    ];
}


