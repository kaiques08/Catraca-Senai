<?php

require_once __DIR__ . '/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input) || empty($input['cpf']) || empty($input['tipo'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Campos obrigatórios: cpf, tipo']);
    exit;
}

$cpf  = (string)$input['cpf'];
$tipo = (string)$input['tipo']; // esquecimento, perda, uniforme

try {
    $permitido = verificarLimite($cpf, $tipo);

    if (!$permitido) {
        echo json_encode([
            'success'   => true,
            'permitido' => false,
            'mensagem'  => 'Limite de ocorrências atingido para este período.',
        ]);
        exit;
    }

    registrarOcorrencia($cpf, $tipo);

    echo json_encode([
        'success'   => true,
        'permitido' => true,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Erro interno ao registrar ocorrência',
    ]);
}


