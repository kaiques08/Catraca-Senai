<?php
declare(strict_types=1);
require __DIR__ . '/secure_bootstrap.php';
$_SESSION['user_id'] = 1;
echo 'Login de teste OK';
