<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $https,
    'httponly' => true,
    'samesite' => 'Strict'
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!isset($_SESSION['last_activity'])) {
    $_SESSION['last_activity'] = time();
} else {
    $timeout = 1800;
    if (time() - (int)$_SESSION['last_activity'] > $timeout) {
        $_SESSION = [];
        session_destroy();
        http_response_code(403);
        echo 'Sessão expirada';
        exit;
    }
    $_SESSION['last_activity'] = time();
}
$fp = hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . ($_SERVER['REMOTE_ADDR'] ?? ''));
if (!isset($_SESSION['fingerprint'])) {
    $_SESSION['fingerprint'] = $fp;
} elseif ($_SESSION['fingerprint'] !== $fp) {
    $_SESSION = [];
    session_destroy();
    http_response_code(403);
    echo 'Sessão inválida';
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
if (!isset($_SESSION['regenerated'])) {
    session_regenerate_id(true);
    $_SESSION['regenerated'] = true;
}

function csrf_token(): string { return $_SESSION['csrf_token'] ?? ''; }
function verify_csrf(string $token): bool { return hash_equals($_SESSION['csrf_token'] ?? '', $token); }

function require_auth(): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(403);
        echo 'Acesso negado';
        exit;
    }
}

function pdo(): PDO { return getPDO(); }
